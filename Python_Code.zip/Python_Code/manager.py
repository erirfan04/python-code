
"""
Write a program which will take one number from the user and display number is positive/negative/zero
Write a program which will find smallest of given two number
"""
a=int(input("Enter value1="))
b=int(input("Enter value1="))

def checkNumber():
    if(a>b):
        print("Smaller Number=",b)
    else:
        print("Small")

checkNumber()

#raw_input() it is depricated in python 3.0
#input()-- it used to take input from the users.it will always give value in form of String