import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, Lasso, Ridge, ElasticNet

# Example dataset
X = np.array([[1,2], [2,3], [3,4], [4,5], [5,6]])
y = np.array([2.3, 3.1, 4.7, 6.2, 7.8])

# Multiple Linear Regression
mlr = LinearRegression()
mlr.fit(X, y)

# Lasso Regression
lasso = Lasso(alpha=0.1)  # alpha = λ
lasso.fit(X, y)

# Ridge Regression
ridge = Ridge(alpha=0.1)
ridge.fit(X, y)

# Elastic Net
elastic = ElasticNet(alpha=0.1, l1_ratio=0.5)
elastic.fit(X, y)

print("MLR Coeffs:", mlr.coef_)
print("Lasso Coeffs:", lasso.coef_)
print("Ridge Coeffs:", ridge.coef_)
print("Elastic Net Coeffs:", elastic.coef_)
