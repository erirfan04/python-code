"""
v=np.array([1,2,3])
print(v) #-->vector
=====================================
m=np.array([[1,2,3],[4,5,6]])
 m #-->matrix
 =======================
 t=np.array([[[1,2],[3,4]],[[5,6],[7,8]]]) #--> Tensor
 ===============================
specify the data type when creating a NumPy array using the
dtype parameter
np.array([1,2,3],dtype=float)
================================

np.arange(10)

=======================

np.arange(1,11).reshape(5,2)-- first attribute represent row an second column

=====================

np.ones((2,2))
np.zeros((2,2))

=============================

import numpy as np
a = np.random.randint(1,100,15)--- used to generate a random integer within a specified range

=============================

b= np.random.randint(1,100,24).reshape(6,4)
===================================

sorting
a = np.random.randint(1,100,15)
print(a)
b= np.random.randint(1,100,24).reshape(6,4)
print(b)
print(np.sort(b,axis=0)) #column wise sorting
print(np.sort(a)[::-1]) #reverse sorting
print(np.sort(b)) #natural sorting in assending order
================================================

np.append()
x = np.random.randint(1,100,15)
np.append(x,200)
====================
x= np.random.randint(1,100,24).reshape(6,4)
y=np.array([1,2,3,4])
print(np.append(y,[1,2,3,4]))
print()
print(np.append(x,y))
================================
np.unique()
e=np.unique([11,2,2,2,33,3,33,11])
np.unique(e)
==============================

np.where()
x = np.random.randint(1,100,15).reshape(3,5)
print(x)
y=np.where(x>80)  #find all index with values greater than 50
print(y)
z=np.where(x>50,0,x)
print(z)


Tensors in TensorFlow are multi-dimensional arrays used to represent data. They generalize the concepts of:
Scalar:
A single numerical value (e.g., 1).
Vector:
A one-dimensional array of numbers (e.g.,).
Matrix:
A two-dimensional array of numbers (e.g., [,]).
Tensor:
A multi-dimensional array, extending beyond two dimensions (e.g., [[,]]).
=========================
numpy.append()

Purpose: Appends values to the end of an array.

Creates a new array (does not modify in-place)

numpy.concatenate()

Purpose: Joins a sequence of arrays along an existing axis.

Arrays must have matching dimensions (except for the concatenation axis)..

import numpy as np
c=np.arange(6).reshape(2,3)
d=np.arange(6,12).reshape(2,3)
print(c)
print()
print(d)

e=np.concatenate((c,d)) #default concatenation row-wise
print()
print(e)

"""



import numpy as np

x = np.random.randint(1,100,15).reshape(3,5)
print(x)
y=np.where(x>80)  #find all index with values greater than 50
print(y)
z=np.where(x>50,0,x)
print(z)






