import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR

# Example data
X = np.array([[1], [2], [3], [4], [5]])
y = np.array([1.5, 3.7, 3.0, 5.5, 6.7])

# Decision Tree Regression
tree = DecisionTreeRegressor(max_depth=3)
tree.fit(X, y)
y_pred_tree = tree.predict(X)

# Support Vector Regression
svr = SVR(kernel="rbf", C=100, epsilon=0.1)
svr.fit(X, y)
y_pred_svr = svr.predict(X)

# Plot
plt.scatter(X, y, color="black", label="Data")
plt.plot(X, y_pred_tree, color="green", label="Decision Tree")
plt.plot(X, y_pred_svr, color="red", label="SVR")
plt.legend()
plt.show()
