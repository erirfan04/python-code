"""
x=1
while x<=100:  #infinite loop
 print("Hello")
 x=x+1
print("Finish")
def p1():
    string="Hello World"
    for s in string:
        print(s)
def p2():
    s= input("Enter any String")
    i=0
    for x in s:
        print("The charactor present at",i,"index is",x)
        i=i+1

for x in range(10):
    print(x)
for x in range(10,0,-1):
    print(x)

n=int(input("Enter number=")) #10
sum=0
i=1
while(i<=n):
   # sum=sum+i #10
    sum+=i
   # i=i+1 #4
   i+=1
print("The sum of first ",n,"number is: ",sum)
n=int(input("Enter number="))
for x in range(n):
    print(x)

i=1
while(i<10):
    print("Hello")
    i+=1

for x in range(10,0,-2):
    print(x)

    n=int(input("Enter number")) #n=5
for i in range(1,n+1): #i=2
    for j in range(1,i+1):
        print("*",end="")
    print()

    To display odd numbers from 0 to 20
 for x in range(21) :
 if (x%2!=0):
 print(x)
 Write a program to display *'s in pyramid style(also known as equivalent triangle)

8)
9) n = int(input("Enter number of rows:"))
10) for i in range(1,n+1):
11) print(" " * (n-i),end="")
12) print("* "*i)
================================
for x in range(15):
 if i==9:
 print("processing is enough..plz break")
 break
print(i)
=============================
arr=[30,10,700,50,60]
 for item in arr:
 if item>500:
 print("To place this order insurence must be required")
break
 print(item)
====================================

To print odd numbers in the range 0 to 9
 for i in range(10):
 if i%2==0:
 continue
 print(i)

===================================

loops with else block:
Inside loop execution,if break statement not executed ,then only else part will be
executed.
else means loop without break
Eg:
 cart=[10,20,30,40,50]
 for item in cart:
 if item>=200:
   print("We cannot process this order")
 break
 print(item)
 else:
 print("Congrats ...all items processed successfully")
==================================
pass statement:
pass is a keyword in Python.
In our programming syntactically if block is required which won't do anything then we can
define that empty block with pass keyword.
pass
|- It is an empty statement
|- It is null statement
|- It won't do anything

3) pass statement:
pass is a keyword in Python.
In our programming syntactically if block is required which won't do anything then we can
define that empty block with pass keyword.
pass
|- It is an empty statement
|- It is null statement
|- It won't do anything
Eg:
if True:
SyntaxError: unexpected EOF while parsing
if True: pass
==>valid
def m1():
SyntaxError: unexpected EOF while parsing

def m1(): pass
use case of pass:
Sometimes in the parent class we have to declare a function with empty body and child
class responsible to provide proper implementation. Such type of empty body we can
define by using pass keyword. (It is something like abstract method in java)

Eg:
def m1(): pass
Eg:
 for i in range(100):
 if i%9==0:
    print(i)
 else:pass

del statement:
del is a keyword in Python.
After using a variable, it is highly recommended to delete that variable if it is no longer
required,so that the corresponding object is eligible for Garbage Collection.
We can delete variable by using del keyword.
Eg:
1) x=10
2) print(x)
3) del x

After deleting a variable we cannot access that variable otherwise we will get NameError.
Eg:
1) x=10
2) del x
3) print(x)
==========================
String Handling
===========================
s='Elevatemycode'
print(s[0])
=====================================
 s='Elevatemycode'
print(len(s))
=============================
s=input("Enter Some String:")
i=0
for x in s:
 print("The character present at positive index {}  is {}".format(i,x),end="")
 print(" Negative Index {} ".format(i-len(s)))
 i=i+1

==================================
s="This is my world !!!"
n=len(s)
i=0
print("Forward direction")
print(s[3])
while i<n:
 print(s[i],end=' ')
 i+=1
print("\n Backward direction")
i=-1
while i>=-n:
  print(s[i],end=' ')
  i=i-1
=================================
Checking Membership:

s='Hello'
print('e' in s) #True
print('l' in s) #False

===============================

s=input("Enter main string:")
subs=input("Enter sub string:")
if subs in s:
 print(subs,"is found in main string")
 else:
 print(subs,"is not found in main string")
============================================
s=input("Enter main string:")
subs=input("Enter sub string:")
if subs in s:
 print(subs,"is found in main string")
else:
 print(subs,"is not found in main string")
 ====================================================
 Comparison of Strings:
 s1=input("Enter first string:")
s2=input("Enter Second string:")
if s1==s2:
 print("Both strings are equal")
elif s1<s2:
 print("First String is less than Second String")
else:
 print("First String is greater than Second String")
 =======================================================

 Removing spaces from the string:
We can use the following 3 methods
1. rstrip()===>To remove spaces at right hand side
2. lstrip()===>To remove spaces at left hand side
3. strip() ==>To remove spaces both sides
city=input("Enter your city Name:")
scity=city.rstrip()
if scity=='New York':
 print("Hello New York")
elif scity=='Pitts':
 print("Hello Pitts")
elif scity=="New Jersy":
 print("Hello New Jersy")
else:
 print("Invalid City")
================================================

Changing case of a String:
We can change case of a string by using the following 4 methods.
1. upper()===>To convert all characters to upper case
2. lower() ===>To convert all characters to lower case
3. swapcase()===>converts all lower case characters to upper case and all upper case characters to
lower case
4. title() ===>To convert all character to title case. i.e first character in every word should be upper
case and all remaining characters should be in lower case.
5. capitalize() ==>Only first character will be converted to upper case and all remaining characters
can be converted to lower case

s='Hello Python'
print(s.upper())
print(s.lower())
print(s.swapcase())
print(s.title())
print(s.capitalize())
==========================================

result1=text.split()
print(result1)

text = "Hello World"
result = text.replace(" ", "")
print(result)
# Output: HelloWorld

text = "Hello World"
result = "".join(text.split())
print(result)
# Output: HelloWorld







# Reverse the order of words in a string
text = "Python is fun"
result = " ".join(text.split()[::-1])
print(result)
# Output: fun is Python


# Reverse each word but keep the order
text = "Python is fun"
result = " ".join(word[::-1] for word in text.split())
print(result)
# Output: nohtyP si nuf


text = "Python is fun"
result = text[::-1]
print(result)
# Output: nuf si nohtyP

text = "Python"
reversed_text = ""
for ch in text:
    reversed_text = ch + reversed_text   # put each char in front
print(reversed_text)



"""
name="Hello"
print(len(name))
print(name[0])
print(name[1])
print(name[-1])
print(name[-2])

#positive index and negative index




import numpy as np

# Create a 1D array
arr1 = np.array([1, 2, 3, 4, 5])
print("1D Array:", arr1)

# Create a 2D array (matrix)
arr2 = np.array([[1, 2, 3], [4, 5, 6]])
print("2D Array:\n", arr2)

