#type(data type) cast(change)
#changing one type to other type- type cating
#into int
a=10
b=str(a) # converting int to string
c="100"
d=int(c) # converting string to int, that will convertl only if string are having digits.
bo=False
in1=float(bo)
bo1=bool(a)
fl=float(a)
print(a)
print(b)
print(d)
print(in1)
print(bo1)
print(fl)

"""
pre define function for data type
int()
float()
str()
bool()
complex() 
b="hello"
d="100"
fl=100.5
c=int(fl)
fl1=float(True)
re=str(fl)
bo=int(False)
#int to string
#int to float
#float to int
print(re)
print(bo)
print(fl1)

"""