
    """
    Data Types

    Data--peace of information
    calculator

      addition two numbers--10 + 20 =30
      variables-- it is store the data in computer memory
      references--who does stor address

      Agenda of Today

      learn behaviour of reference data type
        learn mutable and immutable concept in data type
        Type casting
        escap Sequence

        no=100 #int
    name="hello" #string
    print(name[10])
    digit=100.0
    c=4+10j;
    d=True
    x=None
    d=bytearray([65, 66, 67])
    b= bytes([65, 66, 67])
    print(type(no))
    print(type(digit))
    print(type(c))
    print(type(d))

    print(b)

    ()
    []
    {}
    Mutable Types (Can be changed in-place)-- one object-changable
    Immutable Types (Any change creates a new object)--one object not changable,
    create new objectmy_list = [1, 2,2, 3]
    my_list.append(4)

    my_tuple = (1, 2,2, 3)
    print(my_tuple)
    print(my_list)

    my_set = {1, 2, 2, 3}
    my_set.add(7)
    print(my_set)

    f = frozenset([1, 2, 3])
    # f.add(4)  # Error: 'frozenset' object has no attribute 'add'
    print(f)  # frozenset({1, 2, 3})

    my_dict = {"name": "Alice", "age": 25}
    print(my_dict["name"])
    print(my_dict["age"])

    x = None #null

    my_b=bytearray([65, 66, 67])
    print(my_b)

    """


    x= "hello"
    print(id(x))          # Memory address of 'hello'
    x += " world"
    print(x)              # "hello world"
    print(id(x))          # New memory address → new object create

    a=10
    print(type(a))

    my_list = [1, 2, 3]
    print(id(my_list))
    my_list.append(4)
    print(my_list)  # [1, 2, 3, 4]
    print(id(my_list))



    # a=a+b/ a+=b--x=x+"word"
