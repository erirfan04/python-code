#Addition, subtraction, multiplication

def addition(): #Body of the function
    a = 10
    b = 20
    add = a + b
    print("Addition=",add)

def subtraction():
    a = 10
    b = 20
    sub = a - b
    print("Subtraction=",sub)

addition() # call of the fuction
addition()
addition()
subtraction()

