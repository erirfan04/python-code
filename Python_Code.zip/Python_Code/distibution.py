import scipy.stats as stats
import pandas as pd

# 1. Normal distribution probability
prob = stats.norm.cdf(1.96)   # P(Z <= 1.96)
print("Probability:", prob)

# 2. Correlation
data = pd.DataFrame({"x":[1,2,3,4], "y":[2,4,6,8]})
print("Correlation:\n", data.corr())

# 3. t-test
a = [5,6,7,8,9]
b = [6,7,8,9,10]
t_stat, p_val = stats.ttest_ind(a, b)
print("t-stat:", t_stat, "p-value:", p_val)