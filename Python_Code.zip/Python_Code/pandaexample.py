
"""
df = pd.read_csv(r"data.csv")


users = pd.DataFrame({"userid":[1, 2, 3], "name":["Allen", "Black", "James"]})


msgs = pd.DataFrame({"userid":[1, 1, 2, 4], "msg":['Ok', "fine", "Nice", "good"]})

#print(pd.concat([users, msgs]))

users.merge(msgs, on="userid")

#print(users.merge(msgs, on = "userid", how="outer"))
#print(users.merge(msgs, on = "userid", how="left"))
print(users.merge(msgs, on = "userid", how="right"))
===================================================================
df = pd.read_csv(r"data.csv")
print(type(df))
Now how can we access a column, say country of the dataframe?
print(df["country"])
Now what is the data-type of a column?
print(type(df["country"]))
How can we find the datatype, name, total entries in each column ?
print(df.info())
Now what if we want to see the first few rows in the dataset ?
print(df.head())
Similarly what if we want to see the last 20 rows ?
df.tail(20) #Similar to head
print(df.shape)
print(df.head(3))
=====================================
How can we create a DataFrame from scratch?
Approach 1: Row-oriented
It takes 2 arguments - Because DataFrame is 2-dimensional
A list of rows
Each row is packed in a list []
All rows are packed in an outside list [[]] - To pass a list of rows
A list of column names/labels

df1=pd.DataFrame([['Afghanistan',1952, 8425333, 'Asia', 28.801, 779.445314 ],
['Afghanistan',1957, 9240934, 'Asia', 30.332, 820.853030 ],
['Afghanistan',1962, 102267083, 'Asia', 31.997, 853.100710 ]],
 columns=['country','year','population','continent','life_exp','gdp_cap'])
print(df1)
======================================
column oriented Approach

pd.DataFrame({'country':['Afghanistan', 'Afghanistan'], 'year':[1952,1957],
'population':[842533, 9240934], 'continent':['Asia', 'Asia'],
'life_exp':[28.801, 30.332], 'gdp_cap':[779.445314, 820.853030]})
=========================================

#print(df)
#print(df.columns)
print(df.keys)
================================

And what if we pass a single column name?
df[['country']].head()

How can we find unique values in a column?
df['country'].unique()
=================================

inplace=True
When inplace is set to False (which is the default behavior for most Pandas functions), the function returns
a new DataFrame or Series with the modifications. The original object remains unchanged. This approach
is generally preferred as it promotes immutability, making code easier to reason about and debug.

inplace=True:
When inplace is set to True, the function performs the operation directly on the original DataFrame or
 Series, modifying it in place. In this case, the function does not return a new object; instead, it returns
  None.

This tells pandas to modify the DataFrame directly, without returning a new one.

df.drop('continent', axis=1, inplace=True)
===============================================

Now what if you also want to check the count of each country in the dataframe?
df['country'].value_counts()
Note: value_counts() shows the output in decreasing order of frequency
=============================
What if we want to change(rename) the name of a column ?
We can rename the column by:
passing the dictionary with old_name:new_name pair
specifying axis=1

print(df.rename({"population": "Population", "country":"Country" }, axis = 1))

axis=1

This tells pandas what you're renaming:

axis=0 → rename row labels (index)

axis=1 → rename column labels

So here, axis=1 means:

"Rename a column (not a row)."
==================================

df.rename(columns={"country":"Country"})
======================================

How to create a column using values from an existing column?
df["year+7"] = df["year"] + 7
df.head()

=========================================

How can we create a new column from our own values?
df = pd.read_csv(r"data.csv")
df["Own"] = [i for i in range(1704)] # count of these values should be correct
df
===============================
The drop function takes two parameters:
The column name
The axis
By default the value of axis is 0
df = pd.read_csv(r"data.csv")
df.drop('continent', axis=1)

We can set parameter inplace=True
By default, inplace=False

immutable
mutable

df.drop(columns=["Own",'gdp', 'year+7'], axis = 1, inplace = True)
========================================
Working with Rows

df.index.values
Can we change row labels (like we did for columns)?
What if we want to start indexing from 1 (instead of 0)?
df.index = list(range(1, df.shape[0]+1)) # create a list of indexes of same length
df
===========================
Now what if we want to use string indices?
sample.index = ['a', 'b', 'c', 'd', 'e']
sample
======================
Can we use one of the columns as row index?
temp = df.set_index("Country")
temp

Now how can we reset our indices back to integers?
df.reset_index()

How can we reset our index without creating this new column?
df.reset_index(drop=True) # By using drop=True we can prevent creation of a new column
===========================

What if we want to access any particular column (say first row)?
ser = df["Country"]
ser.head(20)

ser[12]

ser[5:15]
==================================
df.iloc[4] # The 5th row is printed
iloc → index-location based selection (integer position).
What if we want to access multiple non-consecutive rows at same time ?
For eg: rows 1, 10, 100
df.iloc[[1, 10, 100]]
loc
Allows indexing and slicing that always references the explicit index
loc → label based selection (index name/label).
df.loc[4] # The 4th row is printed
df.loc[1]
df.loc[1:3]

================================
iloc
Allows indexing and slicing that always references the implicit Python-style index
df.iloc[1]

df.iloc[0:2]

===========================

Can we do sorting on multiple columns?
YES
df.sort_values(['year', 'life_exp'])
===========================================
How can we have different sorting orders for different columns in multi-level sorting?
df.sort_values(['year', 'life_exp'], ascending=[False, True

===================================================

Concatenating DataFrames
Let's use a mini use-case of users and messages
users --> Stores the user details - IDs and Names of users

users = pd.DataFrame({"userid":[1, 2, 3], "name":["Allen", "Black", "James"]})
users

msgs = pd.DataFrame({"userid":[1, 1, 2, 4], "msg":['Ok', "fine", "Nice", "good"]})
msgs
pd.concat([users, msgs])

=======================================

users = pd.DataFrame({"userid":[1, 2, 3], "name":["Allen", "Black", "James"]})
#print(users)

msgs = pd.DataFrame({"userid":[1, 1, 2, 4], "msg":['Ok', "fine", "Nice", "good"]})
#print(msgs)

print(pd.concat([users, msgs]))
print(pd.concat([users, msgs], axis=0))
print(pd.concat([users, msgs], axis=1))

concat simply combined/stacked the dataframe horizontally
If you notice, userid 3 for user dataframe is stacked against userid 2 for msg dataframe
This way of stacking doesn't help us gain any insights
=> pd.concat() does not work according to the values in the columns

=====================================
Merging Dataframes

users = pd.DataFrame({"userid":[1, 2, 3], "name":["Allen", "Black", "James"]})

msgs = pd.DataFrame({"userid":[1, 1, 2, 4], "msg":['Ok', "fine", "Nice", "good"]})

users.merge(msgs, on="userid")
#print(users.merge(msgs, on = "userid", how="outer"))
#print(users.merge(msgs, on = "userid", how="left"))
print(users.merge(msgs, on = "userid", how="right"))

==============================================
movies = pd.read_csv('movies.csv')
#Top 5 rows
#print(movies.head())
directors = pd.read_csv('directors.csv',index_col=0)
#print(directors.head())
print(movies.shape)
print(directors.shape)

========================================
Merging the director and movie data
Now, how can we know the details about the Director of a particular movie?
We will have to merge these datasets
So on which column we should merge the dfs ?
We will use the ID columns (representing unique director) in both the datasets

How do we get the number of unique directors in movies ?
print(movies['director_id'].nunique())

===============================
Movies Dataset: 1465 rows, but only 199 unique directors
Directors Dataset: 2349 unique directors (= no of rows)
What can we infer from this?
=> Directors in movies is a subset of directors in directors
Now, how can we check if all director_id values are present in id ?

print(movies['director_id'].isin(directors['id']))

The isin() method checks if the Dataframe column contains the specified value(s).
How is isin different from Python in ?
in works for one element at a time
isin does this for all the values in the column
If you notice,
This is like a boolean "mask"
It returns a df similar to the original df
For rows with values of director_id present in id it returns True, else False

====================================================

Lets finally merge our dataframes
Do we need to keep all the rows for movies?
YES
Do we need to keep all the rows of directors?
NO
only the ones for which we have a corresponding row in movies
So which join type do you think we should apply here ?

print(movies.shape) #(1465, 11)
print(directors.shape)
print(movies['director_id'].nunique())

print(directors['id'].nunique())
========================================
How is isin different from Python in ?
in works for one element at a time
isin does this for all the values in the column
print(movies['director_id'].isin(directors['id']))
======================================

data = movies.merge(directors, how='left', left_on='director_id',right_on='id')
print(data)

=====================================
And hww can we drop multiple rows?
df.drop([1, 2, 4], axis=0) # drops rows with labels 1, 2, 4

# Let's drop row with label 3
df = df.drop(3, axis=0)
df
===========================================

"""

import pandas as pd
movies = pd.read_csv('movies.csv')
#Top 5 rows
#print(movies.head())
directors = pd.read_csv('directors.csv',index_col=0)
#print(directors.head())

data = movies.merge(directors, how='left', left_on='director_id',right_on='id')
#data.drop(['director_id','id_y'],axis=1,inplace=True)
print(data.head())

#print(data.info())

#print(data.describe())
print(data.loc[data['vote_average'] > 7, ['title','director_name']])


