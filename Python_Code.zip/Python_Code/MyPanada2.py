import pandas as pd
df = pd.read_csv(r"data.csv")
print(df)
print(df.drop('continent', axis=1))

df["Own"] = [i+1 for i in range(1704)] # count of these values should be correct
print(df)

print(df.drop('continent', axis=1))

df.index = list(range(1, df.shape[0]+1)) # create a list of indexes of same length
print(df)

sample = df.head()
sample.index = ['a', 'b', 'c', 'd', 'e']
print(sample)

temp = df.set_index("country")
print(temp)

ser = df["country"]
ser.head(20)

print(ser[12])

print(ser[5:15])
print(df.iloc[4])
print(df.loc[4])

print(df.loc[1:3])

print(df.sort_values(['year', 'life_exp']))