
#df = pd.read_csv("data.csv")
#print(type(df))
#print(df["country"])
#print(type(df["country"]))

#print(df.info())
#print(df.head)
#print(df.tail(10))
#print(df.shape)
#print(type(df))
#print(df["country"])
#print(type(df["country"]))

#print(df.info())
#print(df.head)
#print(df.tail(10))
#print(df.shape)
#name of all all the column
#print(df.columns)
#print(df.keys)
#print(df[['country','life_exp']].head)

#print(df['country'].unique())

#print(df['country'].value_counts())

#print(df.rename({"population":"Population","country":"Country"}, axis=1))

#print(df.drop(columns=['continent']))

#df["year+7"]=df["year"]+7
#print(df.head())
""""
users = pd.DataFrame({"userid":[1, 2, 3], "name":["Allen", "Black", "James"]})
#print(users)

msgs = pd.DataFrame({"userid":[1, 1, 2, 4], "msg":['Ok', "fine", "Nice", "good"]})
pd.concat([users, msgs])

By default, axis=0 (row-wise) for concatenation
userid , being same in both DataFrames, was combined into a single column
First values of users dataframe were placed, with values of column msg as NaN
Then values of msgs dataframe were placed, with values of column msg as NaN
The original indices of the rows were preserved

===================================
Now how can we make the indices unique for each row?
pd.concat([users, msgs], ignore_index = True)
============================================
How can we concatenate them horizontally?
pd.concat([users, msgs], axis=1)

concat simply combined/stacked the dataframe horizontally
If you notice, userid 3 for user dataframe is stacked against userid 2 for msg dataframe
This way of stacking doesn't help us gain any insights
=> pd.concat() does not work according to the values in the columns
We need to merge the data
==============================================

How can we join the dataframes ?
users.merge(msgs, on="userid")
Notice that users has a userid = 3 but msgs does not
When we merge these dataframes the userid = 3 is not included
In [104… pd.concat([users, msgs], axis=1)
Out[104]:
In [105… users.merge(msgs, on="userid")
Out[105]:
Similarly, userid = 4 is not present in users , and thus not included
Only the userid common in both dataframes is shown
What type of join is this?
Inner Join
Remember joins from SQL?
==================================
users.merge(msgs, on = "userid", how="outer")

The on parameter specifies the key , similar to primary key in SQL

=======================================
And what if we want the info of all the users in the dataframe?
users.merge(msgs, on = "userid",how="left")
=====================================
Similarly, what if we want all the messages and info only for the users who sent a
message?
users.merge(msgs, on = "userid", how="right")
===========================
Let's rename our users column userid to id

users.rename(columns = {"userid": "id"}, inplace = True)
users
=============================

Now, how can we merge the 2 dataframes when the key has a different name ?

users.merge(msgs, left_on="id", right_on="userid")

left_on : Specifies the key of the 1st dataframe (users here)
right_on : Specifies the key of the 2nd dataframe (msgs here)
========================================


#print(msgs)
print(users.merge(msgs, on="userid"))
"""
"""
movies = pd.read_csv('movies.csv')
#Top 5 rows
#print(movies.head())
directors = pd.read_csv('directors.csv',index_col=0)
#print(directors.head())
print(movies)
print(directors)
data = movies.merge(directors, how='left', left_on='director_id',right_on='id')
print(data)

print()

data.drop(['director_id','id_y'],axis=1,inplace=True)
print(data.head())
=====================
How can we describe these features to know more about their range of values?
movies = pd.read_csv('movies.csv')
directors = pd.read_csv('directors.csv')
data = movies.merge(directors, how='left', left_on='director_id',right_on='id')
data.describe()
This gives us all statistical properties of the columns
If you notice, some columns such as "title", "month" are missing
How are these missing columns different?
They are of object dtype
==============================
print(data.info())
print(data.describe())

This gives us all statistical properties of the columns
If you notice, some columns such as "title", "month" are missing
How are these missing columns different?
They are of object dtype
Then how can we include object type in df.describe() ?
data.describe(include=object)
=========================================
How can we change the values of revenue and budget into million dollars USD?
data['revenue'] = (data['revenue']/1000000).round(2)
data
====================================
Similarly, we can do it for 'budget' as well
data['budget']=(data['budget']/1000000).round(2)
data.head()
=========================================
Lets first create a mask to filter such movies
In SQL: SELECT * FROM movies WHERE vote_average > 7
In pandas:
data['vote_average'] > 7
=================================
Now, how can we return a subset of columns, say, only title and director_name ?
data.loc[data['vote_average'] > 7, ['title','director_name']]
=====================================================
What if we want to filter highly rated movies released after 2016?
Notice that two conditions are involved here
1. Movies need to be highly rated i.e.. > 7
2. They should be 2017 and onwards
We can use AND operator b/w multiple conditions
data.loc[(data['vote_average'] > 7) & (data['year'] >= 2015)].head()
==============================================
Similarly how can we find movies released on either Friday or Sunday?
data.loc[(data['day'] == 'Friday') | (data['day'] == 'Saturday')].head()
=======================================================
How will you find Top 5 most popular movies?
We can simply sort our data based on values of column 'popularity'
data.sort_values(['popularity'],ascending=False).head(5)
================================
On applying this to a string column, it sorts the dataframe *lexicographically

Lexicographical order, when applied to strings, refers to the method of arranging or comparing strings 
based on a generalized alphabetical order, similar to how words are ordered in a dictionary.

data.sort_values(['title'],ascending=False).head(5)
=========================================
Now, how will get list of movies directed by a particular director, say, 'Christopher
Nolan'?
data.loc[data['director_name'] == 'Christopher Nolan',['title']]
=================================
Apply
Now suppose we want to convert our Gender column data to numerical format
Basically,
0 for Male
1 for Female
How can we encode the column?
Let's first write a function to do it for a single value

  def encode(data):
 if data == "Male":
   return 0
 else:
  return 1
  
data['gender'] = data['gender'].apply(encode)  

movies = pd.read_csv('movies.csv')
directors = pd.read_csv('directors.csv')
data = movies.merge(directors, how='left', left_on='director_id',right_on='id')
========================================
How to find sum of revenue and budget per movie?
data[['revenue', 'budget']].apply(np.sum)
===================================

How can we use apply to work on individual rows?

data[['revenue', 'budget']].apply(np.sum, axis=1)

==================================
Similarly, how can I find profit per movie (revenue-budget)?

def prof(x): # We define a function to calculate profit
return x['revenue']-x['budget']

data['profit'] = data[['revenue', 'budget']].apply(prof, axis = 1)
data
=================================
Grouping
How can we know the number of movies released by a particular director, say,
Christopher Nolan?

data.loc[data['director_name'] == 'Christopher Nolan',['title']].count()
================================================
What if we have to do find number of movies of each director?
We have value_counts() for this
data["director_name"].value_counts()
"""
import numpy as np
import pandas as pd
movies = pd.read_csv('movies.csv')
directors = pd.read_csv('directors.csv')
data = movies.merge(directors, how='left', left_on='director_id',right_on='id')
var=data.loc[data['director_name'] == 'Christopher Nolan',['title']].count()
print(var)


