
import pandas as pd
import numpy as np

movies = pd.read_csv('movies.csv')

directors = pd.read_csv('directors.csv')
#print(movies)
#print(directors)

data = movies.merge(directors, how='left', left_on='director_id',right_on='id')

data.drop(['director_id','id_y'],axis=1,inplace=True)
#print(data.head())
#print(data.info())
#print(data.describe(include=object))
print(data["revenue"])

data['revenue'] = (data['revenue']/1000000).round(2)
print(data['revenue'])
print()
data['budget']=(data['budget']/1000000).round(2)
print(data['budget'])

var=data['vote_average'] > 7

print(var)
"""
users = pd.DataFrame({"userid":[1, 2, 3], "name":["Allen", "Black", "James"]})
#print(users)

msgs = pd.DataFrame({"userid":[1, 1, 2, 4], "msg":['Ok', "fine", "Nice", "good"]})
#print(msgs)
print(pd.concat([users, msgs]))
print()
print(pd.concat([users, msgs], axis=1))

print(users.merge(msgs, on="userid")) # inner merge

print()
print(users.merge(msgs, on = "userid", how="outer")) #Outer merge

print(users.merge(msgs, on = "userid",how="right")) #left merge

"""