"""
s="This is my world"
n=len(s)
i=0
print("Forward direction")
while i<n:
 print(s[i],end='')
 i+=1
print("\n Backward direction")
i=-1
while i>=-n:
  print(s[i],end='')
  i=i-1
  s=input("Enter main string:")
subs=input("Enter sub string:")
if subs in s:
 print(subs,"is found in main string")
else:
 print(subs,"is not found in main string")
"""

text = "Python"
reversed_text = ""
for ch in text:
    reversed_text = ch + reversed_text   # put each char in front
print(reversed_text)
"""
# WAP to reverse string

Hello Word

1.deoW olleH
2.World olleH
3.

"""