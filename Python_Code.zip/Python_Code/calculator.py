
def add(a,b):
    add = a + b;
    return add


#call the function-- using the function
#creating the function-- we are writing body of the function
result=add(10,20) # call of the add function
print(result)
print(add(30,10))

result1=add(20,30)
print(result1)


#parameters/argument -- it is a way of passing the value from caller to function defination

#return -- passing value from function body/function defination to finction call

#return
"""
a=10
b=20
add=a+b;
sub=a-b
mul=a*b
divide=a/b
print(add)
print(sub)
print(mul)
print(divide)

"""