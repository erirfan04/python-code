import pandas as pd

# Example dataset
data = {
    "Name": ["Alice", "Bob", "Charlie", "David"],
    "Age": [25, None, 30, 28],
    "Salary": [50000, 60000, None, 55000]
}
df = pd.DataFrame(data)

# Check for missing values
print(df.isnull())       # True where value is missing
print(df.isnull().sum()) # Count of missing values per column

# Fill with mean / median / mode
df["Age"].fillna(df["Age"].mean(), inplace=True)    # Mean
df["Salary"].fillna(df["Salary"].median(), inplace=True)  #

print(df)
"""
1. Detect Missing Values
import pandas as pd

# Example dataset
data = {
    "Name": ["Alice", "Bob", "Charlie", "David"],
    "Age": [25, None, 30, 28],
    "Salary": [50000, 60000, None, 55000]
}
df = pd.DataFrame(data)

# Check for missing values
print(df.isnull())       # True where value is missing
print(df.isnull().sum()) # Count of missing values per column

🔹 2. Drop Missing Values
# Drop rows with missing values
df_drop_row = df.dropna()

# Drop columns with missing values
df_drop_col = df.dropna(axis=1)

🔹 3. Fill Missing Values (Simple Imputation)
# Fill with constant
df_fill_const = df.fillna(0)

# Fill with mean / median / mode
df["Age"].fillna(df["Age"].mean(), inplace=True)    # Mean
df["Salary"].fillna(df["Salary"].median(), inplace=True)  # Median

🔹 4. Forward & Backward Fill (Time-Series)
df_ffill = df.fillna(method="ffill")   # Forward fill
df_bfill = df.fillna(method="bfill")   # Backward fill

🔹 5. Advanced Imputation (sklearn)
from sklearn.impute import SimpleImputer

# Replace missing values with mean
imputer = SimpleImputer(strategy="mean")
df[["Age", "Salary"]] = imputer.fit_transform(df[["Age", "Salary"]])

# Replace missing values with most frequent value (mode)
imputer_mode = SimpleImputer(strategy="most_frequent")
df[["Age", "Salary"]] = imputer_mode.fit_transform(df[["Age", "Salary"]])

🔹 6. ML-based Imputation
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer

# ML-based imputation (uses regression)
imputer_ml = IterativeImputer()
df[["Age", "Salary"]] = imputer_ml.fit_transform(df[["Age", "Salary"]])


✅ Summary

Use dropna() if very few missing values.

Use fillna() (mean/median/mode) for simple replacement.

Use forward/backward fill for sequential data.

Use sklearn imputers for advanced cases.

Use ML-based imputation for complex datasets.
"""