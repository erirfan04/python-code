import pandas as pd
df = pd.DataFrame({"Fruit": ["Apple","Apple","Banana","Orange","Apple","Banana"]})
print(df["Fruit"].value_counts(normalize=True))