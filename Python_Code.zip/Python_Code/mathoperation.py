import numpy as np
import pandas as pd

# Example dataset
data = [12, 15, 14, 10, 18, 20, 22, 30, 28, 15]

# Descriptive stats
print("Mean:", np.mean(data))
print("Median:", np.median(data))
print("Standard Deviation:", np.std(data))
print("Variance:", np.var(data))
print("Skewness:", pd.Series(data).skew())
print("Kurtosis:", pd.Series(data).kurt())