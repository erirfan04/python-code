from bs4 import BeautifulSoup

html_doc = """
<html>
  <head><title>My Website</title></head>
  <body>
    <h1>Hello, World!</h1>
    <p class="info">This is an example paragraph.</p>
    <a href="https://example.com">Visit Example</a>
  </body>
</html>
"""

# Parse HTML
soup = BeautifulSoup(html_doc, "html.parser")

# Extract title
print(soup.title.text)   # Output: My Website

# Extract paragraph text
print(soup.find("p").text)   # Output: This is an example paragraph.

# Extract link
print(soup.find("a")["href"])  # Output: https://example.com