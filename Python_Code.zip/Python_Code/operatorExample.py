
a=20
b=20
a+=b # a=a+b 30
b*=a # b=b*a, 600
print(b)
c=a!=b or a>b
print(c)
print("hello\"world")


#and-- if all condition true then result will be true, if any condition false, result will be false
#or- if any condition true , result will be true

"""
Arithmetic Operator== +, -, *, /, %(reminder)
Relation Operator- <,>,<=,>= Result will be either true/false
Equality Operator
   ==, !=
Logical Operator
and-- if all condition true then only the result will be true if any of the condition will false then result will be false
or--if any of the condtion true then result will be true

True-1
False-0

and

1*0=0
or(+)
True
1+0=1

print("hello\tworld")
print("hello\rworld")
print("hello\bworld")
print("hello\fworld")
print("hello\vworld")
print("hello\'world")
print("hello\"world")
print("hello\\world")
"""