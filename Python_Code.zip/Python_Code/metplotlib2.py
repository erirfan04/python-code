import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Create figure
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Data for line
x = [0, 1, 2, 3, 4, 5]
y = [0, 1, 4, 9, 16, 25]
z = [0, 2, 4, 6, 8, 10]

# Plot line in 3D
ax.plot(x, y, z, label="3D Line", color="blue")
ax.set_title("3D Line Plot")
ax.set_xlabel("X axis")
ax.set_ylabel("Y axis")
ax.set_zlabel("Z axis")

plt.legend()
plt.show()