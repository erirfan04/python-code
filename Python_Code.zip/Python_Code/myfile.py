print("hello\vworld")
x = "hello"
print(id(x))          # Memory address of 'hello'
x += " world"
print(x)              # "hello world"
print(id(x))          # New memory address → new object created

# After writing the code it does check syntax--
# it does exute code

"""
b = bytearray([65, 66, 67])
print(b)        # bytearray(b'ABC')
b[0] = 68
print(b) 

r = range(1, 5)
print(list(r))  # [1, 2, 3, 4]

my_list = [1, 2, 3]
my_list.append(4)
print(my_list)  # [1, 2, 3, 4]

my_tuple = (1, 2, 3)
print(my_tuple[1])  # 2

my_set = {1, 2, 2, 3}
print(my_set)  # {1, 2, 3}

f = frozenset([1, 2, 3])
# f.add(4)  # Error: 'frozenset' object has no attribute 'add'
print(f)  # frozenset({1, 2, 3})

my_dict = {"name": "Alice", "age": 25}
print(my_dict["name"])  # Alice

x = None
if x is None:
    print("x is None")  # Output: x is None
    
Mutable Types (Can be changed in-place)
Examples:
  list,dict,set,bytearray

my_list = [1, 2, 3]
my_list.append(4)
print(my_list)  # [1, 2, 3, 4]

🔒 Immutable Types (Any change creates a new object)
Examples:
int, float, str, tuple, bool, frozenset, bytes

x = "hello"
print(id(x))          # Memory address of 'hello'
x += " world"
print(x)              # "hello world"
print(id(x))          # New memory address → new object create

Example Comparison

# Mutable
a = [1, 2]
b = a
b.append(3)
print(a)  # [1, 2, 3] → `a` is affected because both point to same list

# Immutable
x = "hi"
y = x
y += " there"
print(x)  # "hi" → `x` is unchanged because strings are immutable
✅ Why It Matters
Function arguments: mutable types can change inside functions

Performance: immutable objects are faster to access, safer for keys in dict

Hashability: only immutable types can be used as keys in a dict or items in a set

slicing of String 
slice means a piece
[ ] operator is called slice operator,which can be used to retrieve parts of String.
In Python Strings follows zero based index.
The index can be either +ve or -ve.
+ve index means forward direction from Left to Right
-ve index means backward direction from Right to Left

Type Casting
1. int()
2. float()
3. complex()
4. bool()
5. str()

int(123.987)
2) 123
3) >>> int(10+5j)
4) TypeError: can't convert complex to int
5) >>> int(True)
6) 1
7) >>> int(False)
8) 0
9) >>> int("10")
10) 10
11) >>> int("10.5")
12) ValueError: invalid literal for int() with base 10: '10.5'
13) >>> int("ten")

>>> float(10)
2) 10.0
3) >>> float(10+5j)
4) TypeError: can't convert complex to float
5) >>> float(True)
6) 1.0
7) >>> float(False)
8) 0.0
9) >>> float("10")
10) 10.0
11) >>> float("10.5")
12) 10.5
13) >>> float("ten")
14) ValueError: could not convert string to float: 'ten'
15) >>> float("0B1111")
16) ValueError: could not convert string to float: '0B1111

bool(0)==>False
2) bool(1)==>True
3) bool(10)===>True
4) bool(10.5)===>True
5) bool(0.178)==>True
6) bool(0.0)==>False
7) bool(10-2j)==>True
8) bool(0+1.5j)==>True
9) bool(0+0j)==>False
10) bool("True")==>True
11) bool("False")==>True
12) bool("")==>False

>>> str(10)
2) '10'
3) >>> str(10.5)
4) '10.5'
5) >>> str(10+5j)
6) '(10+5j)'
7) >>> str(True)
8) 'True'

complex(10)==>10+0j
2) complex(10.5)===>10.5+0j
3) complex(True)==>1+0j
4) complex(False)==>0j
5) complex("10")==>10+0j
6) complex("10.5")==>10.5+0j
7) complex("ten")
8) ValueError: complex() arg is a malformed string

1. Arithmetic Operator  + - * / %
2.Relation Operator  < > <= >=
a > b is False
9) a >= b is True
10) a < b is False
11) a <= b is True
3.equality operators:
== , !=
10==20
2) False
3) >>> 10!= 20
4. Logical Operator
and ==>If both arguments are True then only result is True
or ====>If atleast one arugemnt is True then result is True
not ==>complement
True and False ==>False
True or False ===>True
not False ==>True

escape character
1) \n==>New Line
2) \t===>Horizontal tab
3) \r ==>Carriage Return
4) \b===>Back space
5) \f===>Form Feed
6) \v==>Vertical tab
7) \'===>Single quote
8) \"===>Double quote
9) \\===>back slash symbol
print("hello\nworld")
print("hello\tworld")
print("hello\rworld")
print("hello\bworld")
print("hello\fworld")
print("hello\vworld")
print("hello\'world")
print("hello\"world")
print("hello\\world")

Constants:
Constants concept is not applicable in Python.
But it is convention to use only uppercase characters if we don’t want to change value.
MAX_VALUE=10
It is just convention but we can change the value.

>,>=,<,<=

equality operators:
== , !=
"""