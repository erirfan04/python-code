import numpy as np
from scipy.stats import mannwhitneyu

# Bootstrapping mean estimate
data = np.array([5, 7, 8, 10, 12])
boot_means = [np.mean(np.random.choice(data, size=len(data), replace=True)) for _ in range(1000)]
print("Bootstrap mean estimate:", np.mean(boot_means))

# Mann-Whitney U test
group1 = [5, 6, 7]
group2 = [8, 9, 10]
stat, p = mannwhitneyu(group1, group2)
print("Mann-Whitney U test: stat=", stat, "p-value=", p)