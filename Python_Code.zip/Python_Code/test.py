x=100
x=200.0
a=3+2j
bo=True
b = bytes([65, 66, 67])
c="hello"
d=bytearray([65, 66, 67])
r = range(1, 5)
my_list = [1, 2, 3]# ordered and mutable collection
my_tuple = (1, 2, 3)#ordered and immutable collction
my_set = {1, 2, 2, 3}#unordered collection
f = frozenset([1, 2, 3])#immutable version of set
my_dict = {"name": "Alice", "age": 25}# store key value pair
z = None #reperesent absent of data

print(type(d), ",", type(r), ",", type(my_list), ",", type(my_tuple), ",", type(my_set), ",", type(f))
print(type(my_dict), ",", type(z), ",", type(bo), ",", type(b),",", type(x), ",", type(x), ",", type(a), ",", type(c))