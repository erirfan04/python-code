import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

# Dummy stock price data (you’d normally load from CSV)
data = (np.sin(np.linspace(0, 100, 1000))
        + np.random.normal(0, 0.1, 1000))  # Fake data
X, y = [], []

# Prepare data with 60 timesteps
timesteps = 60
for i in range(timesteps, len(data)):
    X.append(data[i-timesteps:i])
    y.append(data[i])

X, y = np.array(X), np.array(y)
X = X.reshape((X.shape[0], X.shape[1], 1))

# Build LSTM model
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape=(timesteps, 1)))
model.add(LSTM(50))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mse')

# Train model
model.fit(X, y, epochs=5, batch_size=32)

# Predict & plot
predictions = model.predict(X)
plt.plot(y, label="Actual")
plt.plot(predictions, label="Predicted")
plt.legend()
plt.show()
