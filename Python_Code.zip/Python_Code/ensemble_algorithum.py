import numpy as np
import pandas as pd
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

# Example (Regression)
X, y = load_boston(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Random Forest Regression (uses averaging)
rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)
rf_reg.fit(X_train, y_train)
y_pred_reg = rf_reg.predict(X_test)

# Example (Classification)
# For simplicity, classify houses as high-price (> median) or low-price
import numpy as np
y_class = (y > np.median(y)).astype(int)
X_train, X_test, y_train, y_test = train_test_split(X, y_class, test_size=0.2)

rf_clf = RandomForestClassifier(n_estimators=100, random_state=42)
rf_clf.fit(X_train, y_train)
y_pred_clf = rf_clf.predict(X_test)
