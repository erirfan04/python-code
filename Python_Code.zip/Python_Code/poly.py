class Cat:
    def speak(self):
        print("Meow")

class Dog:
    def speak(self):
        print("Woof")

def make_sound(animal):
    animal.speak()  # Works with any animal

cat = Cat()
dog = Dog()
make_sound(cat)  # Meow
make_sound(dog)  # Woof
