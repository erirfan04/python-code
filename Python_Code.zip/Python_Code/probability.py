from scipy.stats import bernoulli, binom, poisson, norm

# Bernoulli
print("Bernoulli:", bernoulli.rvs(p=0.5, size=10))

"""
rvs = Random Variates (it generates random samples).

p=0.5 = probability of success = 0.5 (fair coin).

size=10 = generate 10 random trials.
"""
# Binomial (10 trials, prob=0.5)
print("Binomial:", binom.rvs(n=10, p=0.5, size=10))

# Poisson (lambda = 3 events/minute)
print("Poisson:", poisson.rvs(mu=3, size=10))

# Normal distribution
print("Normal:", norm.rvs(loc=0, scale=1, size=10))