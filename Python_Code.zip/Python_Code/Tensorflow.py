import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# Simple NN model
model = keras.Sequential([
    layers.Dense(16, activation="relu", input_shape=(10,)),  # 10 input features
    layers.Dense(8, activation="relu"),
    layers.Dense(1, activation="sigmoid")  # output (binary classification)
])

# Compile model
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

# Fake data
import numpy as np
X = np.random.rand(100, 10)
y = np.random.randint(0, 2, 100)

# Train model
model.fit(X, y, epochs=5, batch_size=8)