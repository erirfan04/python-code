from sklearn.ensemble import IsolationForest
import numpy as np

# Example data
X = np.array([[10], [11], [12], [13], [100], [14], [15]])  # 100 is anomaly

# Fit Isolation Forest
clf = IsolationForest(contamination=0.1, random_state=42)
labels = clf.fit_predict(X)

print("Predictions:", labels)  # -1 = anomaly, 1 = normal