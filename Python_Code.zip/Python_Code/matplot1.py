import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# Create a figure
plt.plot([1,4,3,8],[1,4,3,8],[1,4,3,8])
plt.show( )

"""
================================

fig = plt.figure()
ax = plt.axes()
# Optionally, you can add some data and labels to the axes
x = [0, 1, 2, 3, 4]
y = [0, 1, 4, 9, 16]
ax.plot(x, y)
# Set the labels and title
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title('Simple Plot')
# Display the plot
plt.show()
=============================
Figure and Subplots
fig = plt.figure()
ax1 = fig.add_subplot(2, 2, 1)
ax2 = fig.add_subplot(2, 2, 2)
ax3 = fig.add_subplot(2, 2, 3)
ax4 = fig.add_subplot(2, 2, 4)
# Optionally, you can add some data to each subplot
ax1.plot([0, 1, 2], [0, 1, 4])
ax2.plot([0, 1, 2], [0, -1, -4])
ax3.plot([0, 1, 2], [0, 2, 1])
ax4.plot([0, 1, 2], [0, -2, 1])
# Display the figure with subplots
plt.show()
Create a figure
fig = plt.figure()


plt.figure() creates a new figure window (like a blank canvas).

All plots (subplots, charts, etc.) will be drawn inside this figure.

🔹 2. Add subplots in a grid
ax1 = fig.add_subplot(2, 2, 1)
ax2 = fig.add_subplot(2, 2, 2)
ax3 = fig.add_subplot(2, 2, 3)
ax4 = fig.add_subplot(2, 2, 4)


fig.add_subplot(rows, cols, index) adds a subplot in the figure.

Here, (2, 2, x) means we are dividing the figure into a 2x2 grid (2 rows, 2 columns).

The last number (1, 2, 3, 4) specifies position of the subplot (counting left-to-right, top-to-bottom).

So:

ax1 → top-left

ax2 → top-right

ax3 → bottom-left

ax4 → bottom-right

🔹 3. Plot data on each subplot
ax1.plot([0, 1, 2], [0, 1, 4])   # y = x^2 (parabola)
ax2.plot([0, 1, 2], [0, -1, -4]) # inverted parabola
ax3.plot([0, 1, 2], [0, 2, 1])   # a curve with peak at middle
ax4.plot([0, 1, 2], [0, -2, 1])  # a curve dipping then rising


Each ax.plot(x, y) draws a line on that specific subplot.

ax1 shows an upward curve.

ax2 shows a downward curve.

ax3 shows a small hill shape.

ax4 shows a dip and rise.

🔹 4. Show the figure
plt.show()
=======================================
Saving the Plot
# Create a figure
fig = plt.figure()
# Add subplots in a 2x2 grid
ax1 = fig.add_subplot(2, 2, 1)
ax2 = fig.add_subplot(2, 2, 2)
ax3 = fig.add_subplot(2, 2, 3)
ax4 = fig.add_subplot(2, 2, 4)
# Optionally, add some data to each subplot
ax1.plot([0, 1, 2], [0, 1, 4])
ax2.plot([0, 1, 2], [0, -1, -4])
ax3.plot([0, 1, 2], [0, 2, 1])
ax4.plot([0, 1, 2], [0, -2, 1])
# Save the figure to a file
fig.savefig('fig1.png')
# Optionally, display the figure
plt.show()
======================================
Line Plot
A line plot is used to represent data points connected by straight 
lines. It’s commonly used for showing
trends over a continuous interval.
x = [1, 2, 3, 4, 5]
y = [2, 4, 6, 4, 2]
plt.plot(x, y)
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Line Plot')
plt.show()
===================================
Bar Plot
A bar plot (or bar chart) is used to represent categorical data with 
rectangular bars. It’s suitable for
comparing categories or showing the distribution of data.

categories = ['A', 'B', 'C', 'D']
values = [10, 15, 8, 38]
plt.bar(categories, values)
plt.xlabel('Categories')
plt.ylabel('Values')
plt.title('Bar Plot')
plt.show()
==================
Scatter Plot
A scatter plot is used to visualize the relationship between two variables. Each point on the plot represents
a data point with two values.
x = [10, 20, 30, 40, 50]
y = [20, 40, 20, 60, 40]
plt.scatter(x, y)
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Scatter Plot')
plt.show()
=================================
Pie Chart
A pie chart is used to represent the parts of a whole. It’s suitable for showing the proportions or percentages
of different categories within a dataset
labels = ['Java', 'Python', 'C++', 'JavaScript']
sizes = [30, 40, 15, 15]  # percentage split
colors = ['gold', 'lightcoral', 'skyblue', 'lightgreen']
explode = (0, 0.1, 0, 0)  # "explode" Python slice for emphasis

# Create pie chart
plt.pie(
    sizes,
    labels=labels,
    colors=colors,
    explode=explode,
    autopct='%1.1f%%',   # show % with 1 decimal place
    shadow=True,
    startangle=140
)

plt.title("Programming Language Popularity")
plt.show()

Explanation:

labels → names for each slice.

sizes → size of each slice (proportional).

colors → custom slice colors.

explode → offset one slice (to highlight it).

autopct → show percentage on slices.

shadow → adds shadow effect.

startangle → rotate the start of the pie chart.
====================================
Setting Colors
plt.plot([1, 2, 3], [4, 5, 6], color='blue')
plt.plot([1, 2, 3], [6, 5, 4], color='red') # Hex color code
plt.show()
=================================
Changing Line Styles
plt.plot([1, 2, 3], [4, 5, 6], linestyle='-', color='blue') # Solid line
plt.plot([1, 2, 3], [6, 5, 4], linestyle='--', color='green') # Dashed line
plt.show()
========================
Customizing Markers
plt.plot([1, 2, 3], [4, 5, 6], marker='o', linestyle='--', color='b')
plt.plot([1, 2, 3], [6, 5, 4], marker='x', color='r')
plt.show()
========================
Customizing Ticks
plt.plot([1, 2, 3], [4, 5, 6])
plt.xticks([1, 2, 3], ['One', 'Two', 'Three'])
plt.yticks([4, 5, 6], ['Four', 'Five', 'Six'])
plt.show()
===================
Adding Labels
plt.plot([1, 2, 3], [4, 5, 6])
plt.xlabel('X Axis Label')
plt.ylabel('Y Axis Label')
plt.title('Title of the Plot')
plt.show()
===========================
Adding Legends
In Matplotlib, a legend is the small box that explains the meaning of 
colors, markers, or line styles used in your plots.
plt.plot([1, 2, 3], [4, 5, 6], label='Line 1')
plt.plot([1, 2, 3], [6, 5, 4], label='Line 2')
plt.legend()
plt.show()
======================
Adding Annotations to the points on the plot
plt.plot([1, 2, 3], [4, 5, 6])
plt.annotate('Point 1', xy=(1, 4), xytext=(1, 5),
arrowprops=dict(facecolor='black', shrink=0.05))
plt.show()
Let us understand the code- plt.annotate adds text annotations to the 
plot. 'Point 1' is the text of the annotation. xy=(1, 4)
specifies the point (1, 4) where the annotation is pointing. 
xytext=(1, 5) specifies the location (1, 5) where the annotation text
should be placed. arrowprops=dict(facecolor='black', shrink=0.05) adds
 an arrow connecting the annotation text to the point.
facecolor='black' sets the color of the arrow to black. shrink=0.05 
slightly shrinks the arrow by 5%.
============================
plt.plot([0, 1, 2], [0, 1, 0], 'b', label='Blue')
plt.plot([0, 1, 2], [1, 0, 1], 'g', label='Green')
plt.plot([0, 1, 2], [0, 0.5, 0], 'r', label='Red')
plt.plot([0, 1, 2], [0.5, 1, 0.5], 'c', label='Cyan')
plt.plot([0, 1, 2], [0.5, 0, 0.5], 'm', label='Magenta')
plt.plot([0, 1, 2], [0.25, 0.75, 0.25], 'y', label='Yellow')
plt.plot([0, 1, 2], [0.75, 0.25, 0.75], 'k', label='Black')
plt.plot([0, 1, 2], [0.1, 0.9, 0.1], 'w', label='White', linestyle='--')
plt.legend()
# Show the plot
plt.show()
# Add a legend

# Sample data
x = [1, 2, 3, 4, 5]
y = [2, 4, 6, 8, 10]

# Create line plot
plt.plot(x, y, label="y = 2x", color="blue", marker="o")

# Add title and labels
plt.title("Simple Line Plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

# Show legend
plt.legend()

# Display the plot
plt.show()
"""