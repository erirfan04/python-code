import matplotlib.pyplot as plt

labels = ['Java', 'Python', 'C++', 'JavaScript']
sizes = [35, 35, 15, 15]  # percentage split
colors = ['gold', 'lightcoral', 'skyblue', 'lightgreen']
explode = (0, 0.1, 0, 0)  # "explode" Python slice for emphasis

# Create pie chart
plt.pie(
    sizes,
    labels=labels,
    colors=colors,
    explode=explode,
    autopct='%1.1f%%',   # show % with 1 decimal place
    shadow=True,
    startangle=140
)

plt.title("Programming Language Popularity")
plt.show()